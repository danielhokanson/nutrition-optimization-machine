import { Component, OnInit, inject, signal, input } from '@angular/core';
import { NonNullableFormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { NotificationService } from '../../../utilities/services/notification.service';

import { AmwButtonComponent, AmwTextareaComponent, AmwIconButtonComponent, AmwTooltipDirective, AmwIconComponent, AmwProgressSpinnerComponent } from 'angular-material-wrap';

import { RecipeService } from '../../services/recipe.service';
import { RecipeRatingModel, RecipeRatingResponseModel } from '../../models/recipe-rating.model';
import { UserInfoService } from '../../../utilities/services/user-info.service';
import { ERROR_MESSAGES } from '../../../shared/constants/error-messages';

@Component({
    selector: 'nom-recipe-ratings',
    standalone: true,
    imports: [
        ReactiveFormsModule,
        AmwButtonComponent,
        AmwTextareaComponent,
        AmwIconButtonComponent,
        AmwTooltipDirective,
        AmwIconComponent,
        AmwProgressSpinnerComponent,
    ],
    templateUrl: './recipe-ratings.component.html',
    styleUrls: ['./recipe-ratings.component.scss']
})
export class RecipeRatingsComponent implements OnInit {
    private recipeService = inject(RecipeService);
    private nonNullableFb = inject(NonNullableFormBuilder);
    private notificationService = inject(NotificationService);
    private userInfoService = inject(UserInfoService);

    recipeId = input.required<number>();

    ratings = signal<RecipeRatingResponseModel[]>([]);
    userRating = signal<RecipeRatingModel | null>(null);
    averageRating = signal(0);
    isLoading = signal(false);
    isSubmitting = signal(false);
    ratingForm: FormGroup = this.nonNullableFb.group({
        rating: [0, [Validators.required, Validators.min(1), Validators.max(5)]],
        comment: ['', [Validators.maxLength(1000)]]
    });

    constructor() {
        // Form is now initialized at declaration
    }

    ngOnInit(): void {
        if (this.recipeId) {
            this.loadRatings();
        }
    }

    loadRatings(): void {
        this.isLoading.set(true);
        this.recipeService.getRatings(this.recipeId()).subscribe({
            next: (ratings) => {
                this.ratings.set(ratings);
                this.calculateAverageRating();
                this.findUserRating();
                this.isLoading.set(false);
            },
            error: (error) => {
                console.error('Error loading ratings:', error);
                this.notificationService.error(ERROR_MESSAGES.RECIPE.RATING_LOAD_FAILED);
                this.isLoading.set(false);
            }
        });
    }

    calculateAverageRating(): void {
        if (this.ratings().length === 0) {
            this.averageRating.set(0);
            return;
        }

        const totalRating = this.ratings().reduce((sum, rating) => sum + rating.rating, 0);
        this.averageRating.set(totalRating / this.ratings().length);
    }

    findUserRating(): void {
        const currentPersonId = this.userInfoService.getCurrentUserInfoValue()?.personId;
        if (currentPersonId) {
            this.userRating.set(this.ratings().find(r => r.authorId === currentPersonId) || null);
        }

        if (this.userRating()) {
            this.ratingForm.patchValue({
                rating: this.userRating()!.rating,
                comment: this.userRating()!.comment || ''
            });
        }
    }

    onSubmit(): void {
        if (this.ratingForm.valid && !this.isSubmitting()) {
            this.isSubmitting.set(true);

            const currentPersonId = this.userInfoService.getCurrentUserInfoValue()?.personId;
            if (!currentPersonId) {
                this.notificationService.error('User information not available. Please log in again.');
                return;
            }

            const ratingData = {
                recipeId: this.recipeId(),
                rating: this.ratingForm.value.rating,
                comment: this.ratingForm.value.comment
            };

            if (this.userRating()) {
                // Update existing rating
                this.recipeService.updateRating(this.userRating()!.id, ratingData).subscribe({
                    next: (updatedRating) => {
                        const index = this.ratings().findIndex(r => r.id === updatedRating.id);
                        if (index !== -1) {
                            const updatedRatings = [...this.ratings()];
                            updatedRatings[index] = updatedRating;
                            this.ratings.set(updatedRatings);
                        }
                        this.userRating.set(updatedRating);
                        this.calculateAverageRating();
                        this.isSubmitting.set(false);
                        this.notificationService.success('Rating updated successfully!');
                    },
                    error: (error) => {
                        console.error('Error updating rating:', error);
                        this.notificationService.error(ERROR_MESSAGES.RECIPE.RATING_SAVE_FAILED);
                        this.isSubmitting.set(false);
                    }
                });
            } else {
                // Add new rating
                this.recipeService.addRating(ratingData).subscribe({
                    next: (newRating) => {
                        this.ratings.set([newRating, ...this.ratings()]);
                        this.userRating.set(newRating);
                        this.calculateAverageRating();
                        this.isSubmitting.set(false);
                        this.notificationService.success('Rating added successfully!');
                    },
                    error: (error) => {
                        console.error('Error adding rating:', error);
                        this.notificationService.error(ERROR_MESSAGES.RECIPE.RATING_SAVE_FAILED);
                        this.isSubmitting.set(false);
                    }
                });
            }
        }
    }

    onDeleteRating(): void {
        if (this.userRating() && confirm('Are you sure you want to delete your rating?')) {
            this.recipeService.deleteRating(this.userRating()!.id).subscribe({
                next: () => {
                    this.ratings.set(this.ratings().filter(r => r.id !== this.userRating()!.id));
                    this.userRating.set(null);
                    this.calculateAverageRating();
                    this.ratingForm.reset();
                    this.notificationService.success('Rating deleted successfully!');
                },
                error: (error) => {
                    console.error('Error deleting rating:', error);
                    this.notificationService.error(ERROR_MESSAGES.RECIPE.RATING_DELETE_FAILED);
                }
            });
        }
    }

    canDeleteRating(rating: RecipeRatingModel): boolean {
        const currentUser = this.userInfoService.getCurrentUserInfoValue();
        if (!currentUser) return false;

        // Check if current user is the author or has admin rights
        return rating.authorId === currentUser.personId || currentUser.isAdmin;
    }

    getStarRating(rating: number): string[] {
        const stars = [];
        for (let i = 1; i <= 5; i++) {
            stars.push(i <= rating ? 'star' : 'star_border');
        }
        return stars;
    }

    formatDate(date: Date): string {
        return new Date(date).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
} 