import { Component, OnInit, input, output, signal, effect } from '@angular/core';
import { NgClass } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

import { AmwButtonComponent, AmwCardComponent, AmwInputComponent, AmwCheckboxComponent, AmwProgressBarComponent, AmwRadioGroupComponent } from 'angular-material-wrap';

interface OnboardingQuestion {
    id: string;
    text: string;
    type: 'text' | 'radio' | 'checkbox' | 'number';
    options?: string[];
    required?: boolean;
}

interface OnboardingAnswer {
    questionIndex: number;
    question: OnboardingQuestion;
    answer: string | number | boolean;
}

@Component({
    selector: 'nom-onboarding-wizard',
    standalone: true,
    imports: [
        NgClass,
        ReactiveFormsModule,
        AmwButtonComponent,
        AmwCheckboxComponent,
        AmwCardComponent,
        AmwInputComponent,
        AmwProgressBarComponent,
        AmwRadioGroupComponent,
    ],
    templateUrl: './onboarding-wizard.component.html',
    styleUrls: ['./onboarding-wizard.component.scss'],
})
export class OnboardingWizardComponent implements OnInit {
    questions = input<OnboardingQuestion[]>([]);
    isLoading = input(false);
    isSubmitting = input(false);
    error = input<string | null>(null);
    submitMessage = input<string | null>(null);

    answerSubmitted = output<OnboardingAnswer>();
    previousQuestion = output<void>();
    nextQuestion = output<void>();
    goToDashboard = output<void>();

    currentQuestionIndex = signal(0);
    currentQuestion: OnboardingQuestion | null = null;
    currentAnswerForm: FormGroup;

    constructor() {
        this.currentAnswerForm = new FormGroup({
            answer: new FormControl('', [Validators.required])
        });

        // Effect to update current question when questions input or currentQuestionIndex changes
        effect(() => {
            this.updateCurrentQuestion();
        });
    }

    ngOnInit(): void {
        this.updateCurrentQuestion();
    }

    private updateCurrentQuestion(): void {
        if (this.questions() && this.questions().length > 0 && this.currentQuestionIndex() < this.questions().length) {
            this.currentQuestion = this.questions()[this.currentQuestionIndex()];
            this.resetForm();
        }
    }

    private resetForm(): void {
        if (this.currentQuestion) {
            this.currentAnswerForm.patchValue({
                answer: ''
            });
        }
    }

    onAnswerChange(value: string | number | boolean): void {
        if (this.currentQuestion) {
            this.currentAnswerForm.patchValue({
                answer: value
            });
        }
    }

    goToPreviousQuestion(): void {
        if (this.currentQuestionIndex() > 0) {
            this.currentQuestionIndex.set(this.currentQuestionIndex() - 1);
            this.updateCurrentQuestion();
            this.previousQuestion.emit();
        }
    }

    goToNextQuestion(): void {
        if (this.currentAnswerForm.valid && this.currentQuestion) {
            const answer = this.currentAnswerForm.get('answer')?.value;
            this.answerSubmitted.emit({
                questionIndex: this.currentQuestionIndex(),
                question: this.currentQuestion,
                answer: answer
            });

            if (this.currentQuestionIndex() < this.questions().length - 1) {
                this.currentQuestionIndex.set(this.currentQuestionIndex() + 1);
                this.updateCurrentQuestion();
                this.nextQuestion.emit();
            }
        }
    }

    onGoToDashboard(): void {
        this.goToDashboard.emit();
    }

    // Helper method for YesNo radio options
    getYesNoOptions(): { value: string; label: string }[] {
        return [
            { value: 'true', label: 'Yes' },
            { value: 'false', label: 'No' }
        ];
    }

    // Helper method for SingleSelect radio options
    getSingleSelectOptions(): { value: string; label: string }[] {
        if (this.currentQuestion?.options) {
            return this.currentQuestion.options.map(option => ({
                value: option,
                label: option
            }));
        }
        return [];
    }
} 