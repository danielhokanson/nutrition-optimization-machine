import { Component, OnInit, input, output, ViewEncapsulation, inject } from '@angular/core';
import {
  FormGroup,
  FormControl,
  FormArray,
  NonNullableFormBuilder,
  ReactiveFormsModule,
} from '@angular/forms';

// Import new child restriction components
import { SocietalRestrictionComponent } from '../societal-restriction/societal-restriction.component';
import { MedicalRestrictionComponent } from '../medical-restriction/medical-restriction.component';
import { PersonalPreferenceRestrictionComponent } from '../personal-preference/personal-preference.component';

import { RestrictionModel } from '../../models/restriction.model';
import { RestrictionService } from '../../services/restriction.service';
import { PersonModel } from '../../../person/models/person.model';
import { RestrictionTypeEnum } from '../../enums/restriction-type.enum';


@Component({
  selector: 'nom-restriction-edit',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    SocietalRestrictionComponent,
    MedicalRestrictionComponent,
    PersonalPreferenceRestrictionComponent,
],
  templateUrl: './restriction-edit.component.html',
  styleUrls: ['./restriction-edit.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class RestrictionEditComponent implements OnInit {
  private fb = inject(NonNullableFormBuilder);
  private restrictionService = inject(RestrictionService);

  restrictions = input<RestrictionModel[]>([]);
  currentPersonId = input(0);
  allPersonsInPlan = input<PersonModel[]>([]);
  restrictionType = input<RestrictionTypeEnum | undefined>(undefined);
  // NEW: Input for whether the restriction applies to the entire plan,
  // this is now managed by OnboardingWorkflowComponent
  appliesToEntirePlan = input(false);
  // NEW: Input for explicitly affected person IDs (if appliesToEntirePlan is false)
  affectedPersonIds = input<number[]>([]);

  formSubmitted = output<RestrictionModel>(); // Changed to single RestrictionModel
  skipStep = output<void>();

  restrictionForm!: FormGroup;

  // Expose the enum to the template
  public RestrictionTypeEnum = RestrictionTypeEnum;



  ngOnInit(): void {
    this.restrictionForm = this.fb.group({
      name: new FormControl(''), // Generic name for the restriction

      // Nested FormGroups for each restriction type
      societalRestrictionForm: this.fb.group({
        societalReligiousEthicalTypeIds: this.fb.array(
          [] as FormControl<number>[]
        ),
        mandatoryInclusions: this.fb.array([] as FormControl<string>[]),
        fastingSchedules: new FormControl(''),
      }),
      medicalRestrictionForm: this.fb.group({
        allergyMedicalIngredientIds: this.fb.array([] as FormControl<string>[]),
        allergyMedicalConditionIds: this.fb.array([] as FormControl<number>[]),
        gastrointestinalConditions: this.fb.array([] as FormControl<number>[]),
        kidneyDiseaseNutrientRestrictions: this.fb.array(
          [] as FormControl<string>[]
        ),
        vitaminMineralDeficiencies: this.fb.array([] as FormControl<string>[]),
        prescriptionInteractions: new FormControl(''),
      }),
      personalPreferenceForm: this.fb.group({
        personalPreferenceSpiceLevel: new FormControl(''),
        dislikedIngredients: this.fb.array([] as FormControl<string>[]),
        dislikedTextures: this.fb.array([] as FormControl<string>[]),
        preferredCookingMethods: this.fb.array([] as FormControl<string>[]),
      }),
    });

    this.patchFormWithExistingRestrictions(this.restrictions());
  }

  private patchFormWithExistingRestrictions(
    existingRestrictions: RestrictionModel[]
  ): void {
    // Clear all FormArrays within the nested form groups initially
    Object.keys(this.restrictionForm.controls).forEach((key) => {
      const control = this.restrictionForm.get(key);
      if (control instanceof FormGroup) {
        Object.keys(control.controls).forEach((subKey) => {
          const subControl = control.get(subKey);
          if (subControl instanceof FormArray) {
            subControl.clear();
          }
        });
      }
    });

    existingRestrictions.forEach((res) => {
      if (res.restrictionTypeId === this.restrictionType()) {
        // Patch the generic name
        this.restrictionForm.patchValue({
          name: res.name || '',
        });

        // Patch the relevant nested FormGroup
        switch (this.restrictionType()) {
          case RestrictionTypeEnum.SocietalReligiousEthical: {
            const societalGroup = this.restrictionForm.get(
              'societalRestrictionForm'
            ) as FormGroup;
            res.societalReligiousEthicalTypeIds?.forEach((id: number) =>
              (
                societalGroup.get(
                  'societalReligiousEthicalTypeIds'
                ) as FormArray
              ).push(this.fb.control(id))
            );
            res.mandatoryInclusions?.forEach((inc: string) =>
              (societalGroup.get('mandatoryInclusions') as FormArray).push(
                this.fb.control(inc)
              )
            );
            societalGroup.patchValue({
              fastingSchedules: res.fastingSchedules,
            });
            break;
          }
          case RestrictionTypeEnum.AllergyMedical: {
            const medicalGroup = this.restrictionForm.get(
              'medicalRestrictionForm'
            ) as FormGroup;
            res.allergyMedicalIngredientIds?.forEach((id: string) =>
              (
                medicalGroup.get('allergyMedicalIngredientIds') as FormArray
              ).push(this.fb.control(id))
            );
            res.allergyMedicalConditionIds?.forEach((id: number) =>
              (
                medicalGroup.get('allergyMedicalConditionIds') as FormArray
              ).push(this.fb.control(id))
            );
            res.gastrointestinalConditions?.forEach((id: number) =>
              (
                medicalGroup.get('gastrointestinalConditions') as FormArray
              ).push(this.fb.control(id))
            );
            res.kidneyDiseaseNutrientRestrictions?.forEach((nut: string) =>
              (
                medicalGroup.get(
                  'kidneyDiseaseNutrientRestrictions'
                ) as FormArray
              ).push(this.fb.control(nut))
            );
            res.vitaminMineralDeficiencies?.forEach((vit: string) =>
              (
                medicalGroup.get('vitaminMineralDeficiencies') as FormArray
              ).push(this.fb.control(vit))
            );
            medicalGroup.patchValue({
              prescriptionInteractions: res.prescriptionInteractions,
            });
            break;
          }
          case RestrictionTypeEnum.PersonalPreference: {
            const personalGroup = this.restrictionForm.get(
              'personalPreferenceForm'
            ) as FormGroup;
            personalGroup.patchValue({
              personalPreferenceSpiceLevel: res.personalPreferenceSpiceLevel,
            });
            res.dislikedIngredients?.forEach((ing: string) =>
              (personalGroup.get('dislikedIngredients') as FormArray).push(
                this.fb.control(ing)
              )
            );
            res.dislikedTextures?.forEach((tex: string) =>
              (personalGroup.get('dislikedTextures') as FormArray).push(
                this.fb.control(tex)
              )
            );
            res.preferredCookingMethods?.forEach((meth: string) =>
              (personalGroup.get('preferredCookingMethods') as FormArray).push(
                this.fb.control(meth)
              )
            );
            break;
          }
        }
      }
    });
  }

  public getRestrictionTypeName(type: RestrictionTypeEnum): string {
    switch (type) {
      case RestrictionTypeEnum.SocietalReligiousEthical:
        return 'Dietary Practice';
      case RestrictionTypeEnum.AllergyMedical:
        return 'Medical Restriction';
      case RestrictionTypeEnum.PersonalPreference:
        return 'Personal Preference';
      default:
        return 'Restriction';
    }
  }

  // --- NEW GETTERS FOR NESTED FORM GROUPS ---
  get societalRestrictionFormGroup(): FormGroup {
    return this.restrictionForm.get('societalRestrictionForm') as FormGroup;
  }

  get medicalRestrictionFormGroup(): FormGroup {
    return this.restrictionForm.get('medicalRestrictionForm') as FormGroup;
  }

  get personalPreferenceFormGroup(): FormGroup {
    return this.restrictionForm.get('personalPreferenceForm') as FormGroup;
  }
  // --- END NEW GETTERS ---

  public submitForm(): void {
    // Mark the relevant nested form group as touched to trigger validation messages
    let formGroupToValidate: FormGroup | null = null;
    let submittedFormValue: Partial<Pick<RestrictionModel,
      'societalReligiousEthicalTypeIds' | 'mandatoryInclusions' | 'fastingSchedules' |
      'allergyMedicalIngredientIds' | 'allergyMedicalConditionIds' | 'gastrointestinalConditions' |
      'kidneyDiseaseNutrientRestrictions' | 'vitaminMineralDeficiencies' | 'prescriptionInteractions' |
      'personalPreferenceSpiceLevel' | 'dislikedIngredients' | 'dislikedTextures' | 'preferredCookingMethods'
    >> = {};

    switch (this.restrictionType()) {
      case RestrictionTypeEnum.SocietalReligiousEthical:
        formGroupToValidate = this.societalRestrictionFormGroup; // Use getter
        submittedFormValue = formGroupToValidate.value;
        break;
      case RestrictionTypeEnum.AllergyMedical:
        formGroupToValidate = this.medicalRestrictionFormGroup; // Use getter
        submittedFormValue = formGroupToValidate.value;
        break;
      case RestrictionTypeEnum.PersonalPreference:
        formGroupToValidate = this.personalPreferenceFormGroup; // Use getter
        submittedFormValue = formGroupToValidate.value;
        break;
      default:
        console.error('Unknown restriction type for submission.');
        return;
    }

    if (formGroupToValidate) {
      formGroupToValidate.markAllAsTouched();
    }

    if (formGroupToValidate && formGroupToValidate.valid) {
      const newRestriction = new RestrictionModel({
        // These are now provided as Inputs from OnboardingWorkflowComponent
        personId: this.appliesToEntirePlan() ? null : this.currentPersonId(),
        planId: this.appliesToEntirePlan() ? 1 : null, // Mock planId 1 if applies to plan, otherwise null
        restrictionTypeId: this.restrictionType()!,
        name: this.getRestrictionTypeName(this.restrictionType()!) + ' Custom', // Name can be refined later if needed

        // Populate type-specific properties from the relevant nested form group
        ...submittedFormValue,

        // Ensure affectedPersonIds is explicitly set based on input from parent
        affectedPersonIds: this.appliesToEntirePlan()
          ? []
          : this.affectedPersonIds(),
        appliesToEntirePlan: this.appliesToEntirePlan(), // Pass this original flag back for consistency with DTO
      });

      this.formSubmitted.emit(newRestriction);
    } else {
      console.error('Restriction form is invalid. Please correct the errors.');
    }
  }

  onSkip(): void {
    this.skipStep.emit();
  }
}
